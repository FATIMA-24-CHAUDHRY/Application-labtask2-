package com.example.applicationform;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class HelloController {
    @FXML
    private TextField nameField;

    @FXML
    private TextField fatherNameField;

    @FXML
    private ComboBox<String> cityComboBox;

    @FXML
    private TextField addressField;

    @FXML
    private TextField emailField;

    @FXML
    private ImageView imageView;

    private File selectedImageFile;

    @FXML
    protected void onUploadImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose an Image");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        selectedImageFile = fileChooser.showOpenDialog(new Stage());
        if (selectedImageFile != null) {
            Image image = new Image(selectedImageFile.toURI().toString());
            imageView.setImage(image);
        }
    }

    @FXML
    protected void onSubmitClick() {
        String name = nameField.getText();
        String fatherName = fatherNameField.getText();
        String city = cityComboBox.getValue();
        String address = addressField.getText();
        String email = emailField.getText();

        if (name.isEmpty() || fatherName.isEmpty() || city == null || address.isEmpty() || email.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            return;
        }

        // Create a StringBuilder for collected data
        StringBuilder formData = new StringBuilder();
        formData.append("Name: ").append(name).append("\n");
        formData.append("Father's Name: ").append(fatherName).append("\n");
        formData.append("City: ").append(city).append("\n");
        formData.append("Address: ").append(address).append("\n");
        formData.append("Email: ").append(email).append("\n");
        if (selectedImageFile != null) {
            formData.append("Image: ").append(selectedImageFile.getAbsolutePath()).append("\n");
        }

        // Show collected data in an alert
        showAlert(Alert.AlertType.INFORMATION, "Form Submitted", formData.toString());
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
