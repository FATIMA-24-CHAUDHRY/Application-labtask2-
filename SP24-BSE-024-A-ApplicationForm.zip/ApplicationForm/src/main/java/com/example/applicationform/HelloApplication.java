package com.example.applicationform;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) {
        // Create the main layout
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(15);
        gridPane.setVgap(15);

        // Banner
        Image bannerImage = new Image(this.getClass().getResource("/banner.png").toExternalForm());
        ImageView bannerImageView = new ImageView(bannerImage);
        bannerImageView.setFitWidth(550);
        bannerImageView.setFitHeight(120);
        gridPane.add(bannerImageView, 0, 0, 2, 1);

        // Name Field
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();
        nameField.setPromptText("Enter your name");
        gridPane.add(nameLabel, 0, 1);
        gridPane.add(nameField, 1, 1);

        // Father's Name Field
        Label fatherNameLabel = new Label("Father's Name:");
        TextField fatherNameField = new TextField();
        fatherNameField.setPromptText("Enter your father's name");
        gridPane.add(fatherNameLabel, 0, 2);
        gridPane.add(fatherNameField, 1, 2);

        // Gender Selection using RadioButtons
        Label genderLabel = new Label("Gender:");
        RadioButton maleRadioButton = new RadioButton("Male");
        RadioButton femaleRadioButton = new RadioButton("Female");
        ToggleGroup genderToggleGroup = new ToggleGroup();
        maleRadioButton.setToggleGroup(genderToggleGroup);
        femaleRadioButton.setToggleGroup(genderToggleGroup);

        HBox genderBox = new HBox(20, maleRadioButton, femaleRadioButton);
        genderBox.setAlignment(Pos.CENTER_LEFT);
        genderBox.setPadding(new Insets(4));
        gridPane.add(genderLabel, 0, 3);
        gridPane.add(genderBox, 1, 3);

        // City Selection
        Label cityLabel = new Label("City:");
        ComboBox<String> cityComboBox = new ComboBox<>();
        cityComboBox.getItems().addAll("Lahore", "Islamabad", "Peshawar", "Karachi", "Quetta", "Multan", "Faisalabad", "Gujranwala");
        cityComboBox.setPromptText("Select your city");
        gridPane.add(cityLabel, 0, 4);
        gridPane.add(cityComboBox, 1, 4);

        // Address Field
        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();
        addressField.setPromptText("Enter your address");
        gridPane.add(addressLabel, 0, 5);
        gridPane.add(addressField, 1, 5);

        // Email Field
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");
        gridPane.add(emailLabel, 0, 6);
        gridPane.add(emailField, 1, 6);

        // FileChooser for Image Upload
        Label imageLabel = new Label("Upload Image:");
        Button uploadButton = new Button("Choose File");
        ImageView previewImageView = new ImageView();
        previewImageView.setFitHeight(50);
        previewImageView.setFitWidth(50);
        FileChooser fileChooser = new FileChooser();
        uploadButton.setOnAction(e -> {
            File file = fileChooser.showOpenDialog(stage);
            if (file != null) {
                Image image = new Image(file.toURI().toString());
                previewImageView.setImage(image);
            }
        });
        HBox imageBox = new HBox(10, uploadButton, previewImageView);
        gridPane.add(imageLabel, 0, 7);
        gridPane.add(imageBox, 1, 7);

        // Submit Button
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            // Collecting Form Data
            String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String city = cityComboBox.getValue();
            String address = addressField.getText();
            String email = emailField.getText();
            String gender = "";
            if (maleRadioButton.isSelected()) {
                gender = "Male";
            } else if (femaleRadioButton.isSelected()) {
                gender = "Female";
            }

            // Validating and Displaying Data
            if (!name.isEmpty() && !fatherName.isEmpty() && city != null && !address.isEmpty() && !email.isEmpty() && !gender.isEmpty()) {
                // Open a new window with submitted data
                showDataWindow(name, fatherName, gender, city, address, email);
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            }
        });

        // Adding Submit Button
        VBox submitBox = new VBox(10, submitButton);
        submitBox.setAlignment(Pos.CENTER_LEFT);
        gridPane.add(submitBox, 1, 8);

        // Setting up the scene
        Scene scene = new Scene(gridPane, 600, 600);
        stage.setTitle("Application Form");
        stage.setScene(scene);
        stage.show();
    }

    private void showDataWindow(String name, String fatherName, String gender, String city, String address, String email) {
        Stage dataStage = new Stage();
        dataStage.setTitle("Submitted Data");

        VBox dataBox = new VBox(10);
        dataBox.setPadding(new Insets(20));
        dataBox.setAlignment(Pos.TOP_LEFT);

        dataBox.getChildren().addAll(
                new Label("Name: " + name),
                new Label("Father's Name: " + fatherName),
                new Label("Gender: " + gender),
                new Label("City: " + city),
                new Label("Address: " + address),
                new Label("Email: " + email)
        );

        Scene dataScene = new Scene(dataBox, 400, 300);
        dataStage.setScene(dataScene);
        dataStage.show();
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}




